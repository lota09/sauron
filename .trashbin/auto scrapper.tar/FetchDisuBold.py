from autoscraper import AutoScraper
from Update import UpdateFetch,FetchSimilar
import Notify

scraper = AutoScraper()
url='https://www.disu.ac.kr/community/notice?cidx=42&page=1'
profile="차세대반도체학과"

if (title:=UpdateFetch('models/disu-title-bold.json',url,'disu-update-bold.txt')):
    date=FetchSimilar("models/disu-date-bold.json",url)[0]
    url=FetchSimilar("models/disu-url-bold.json",url)[0]

    Notify.Email(profile,title,date,url)
python ./FetchEco.py
python ./FetchUsaint.py